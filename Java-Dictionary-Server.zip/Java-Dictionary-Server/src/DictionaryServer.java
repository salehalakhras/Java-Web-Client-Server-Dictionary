import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DictionaryServer {
    // The port on which the server will listen for incoming requests
    private static int PORT;
    // The number of threads in the thread pool used for handling client requests
    private static final int THREAD_POOL_SIZE = 10;
    // The dictionary of words and their meanings
    private static JSONArray DICTIONARY;

    public static void main(String[] args) throws Exception {
        // Parse command line arguments to get the dictionary file path and port number
        JSONParser parser = new JSONParser();
        if (args.length != 2) {
            throw new Exception("No dictionary or no port number provided as an argument");
        } else {
            Reader reader = new FileReader(args[0]);
            DICTIONARY = (JSONArray) parser.parse(reader);
            PORT = Integer.parseInt(args[1]);
        }
        // Create a fixed thread pool of size THREAD_POOL_SIZE to handle client requests
        ExecutorService executorService = Executors.newFixedThreadPool(THREAD_POOL_SIZE);
        // Create a new ServerSocket to listen for incoming requests on the specified port
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server started on port " + PORT);
            // Keep accepting client connections and submitting them to the thread pool for handling
            while (true) {
                Socket clientSocket = serverSocket.accept();
                executorService.execute(new ClientHandler(clientSocket));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private record ClientHandler(Socket clientSocket) implements Runnable {

        @Override
        public void run() {
            try (BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                 PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)) {
                String word;
                // Keep reading words from the client and sending back their meanings, until the client closes the connection
                while ((word = in.readLine()) != null) {
                    JSONObject meaning = findMeaning(word);
                    // If the word is not in the dictionary, send "0" to the client
                    if (meaning == null)
                        out.println("0");
                        // Otherwise, send the word's meaning to the client
                    else
                        out.println(meaning);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        // Find the meaning of a word in the dictionary using binary search
        private JSONObject findMeaning(String word) {
            int wordIndex = binarySearch(word);
            if (wordIndex != -1) {
                return (JSONObject) DICTIONARY.get(wordIndex);
            } else
                return null;
        }

        // Binary search for finding the index of a word in the dictionary
        public static int binarySearch(String target) {
            int low = 0;
            int high = DICTIONARY.size() - 1;

            while (low <= high) {
                int mid = (low + high) / 2;
                JSONObject entry = (JSONObject) DICTIONARY.get(mid);

                if (entry.get("word").toString().compareTo(target.toUpperCase()) < 0) {
                    low = mid + 1;
                } else if (entry.get("word").toString().compareTo(target.toUpperCase()) > 0) {
                    high = mid - 1;
                } else {
                    return mid; // target found
                }
            }
            return -1; // target not found
        }
    }
}