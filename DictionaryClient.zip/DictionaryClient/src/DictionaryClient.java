import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import org.jetbrains.annotations.NotNull;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class DictionaryClient {
    private static String HOST; // server host
    private static int PORT;    // server port

    public static void main(String @NotNull [] args) throws Exception {
        // check for correct command-line arguments
        if (args.length != 2){
            throw new Exception("no host or no port provided as an argument");
        }
        else {
            // set the server host and port
            HOST = args[0];
            PORT = Integer.parseInt(args[1]);
        }

        try (Socket socket = new Socket(HOST, PORT);  // create a new socket to connect to the server
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream())); // set up an input stream to read data from the server
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true); // set up an output stream to send data to the server
             BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in))) { // set up an input stream to read user input from the command line
            String userInput;
            JSONParser parser = new JSONParser(); // create a new JSON parser to parse server responses

            // loop to read user input from the command line
            while ((userInput = stdIn.readLine()) != null) {
                out.println(userInput); // send the user input to the server
                String input = in.readLine(); // read the server's response

                // check if the server responded with "0", indicating that the requested word is not in the dictionary
                if (input.equals("0"))
                    System.out.println("The word " + userInput + " does not exist in the dictionary");
                else {
                    // if the server responded with a JSON object, parse it and display the word's information
                    JSONObject meaning = (JSONObject) parser.parse(input);
                    System.out.println("\nThe word: \"" + meaning.get("word") + "\"");
                    System.out.println("Position in the language: " + meaning.get("pos"));
                    System.out.println("Synonyms: " + meaning.get("synonyms"));
                    System.out.print("Definitions: " + meaning.get("definitions") + "\n\n");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }
}
